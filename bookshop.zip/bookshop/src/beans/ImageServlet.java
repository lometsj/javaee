package beans;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ImageServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public ImageServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException {
request.setCharacterEncoding("utf-8");
BufferedImage bfi= new BufferedImage(80,25,BufferedImage.TYPE_INT_RGB);
Graphics g=bfi.getGraphics();
g.fillRect(0, 0, 80, 25);
char[] ch="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".toCharArray();
Random r=new Random();
int index;
StringBuffer sb=new StringBuffer();
for(int i=0;i<4;i++){
	index=r.nextInt(ch.length);
	g.setColor(new Color(r.nextInt(255),r.nextInt(255),r.nextInt(255)));
	Font font=new Font("宋体",30,20);
	g.setFont(font);
	g.drawString(ch[index]+"", (i*20)+2, 23);
	sb.append(ch[index]);
}
int area=(int)(0.02*80*25);
for(int i=0;i<area;i++){
	int x=(int)(Math.random()*80);
	int y=(int)(Math.random()*25);
	bfi.setRGB(x, y, (int)(Math.random()*255));
}
for(int i=0;i<6;i++){
	int xstart=(int)(Math.random()*80);
	int ystart=(int)(Math.random()*25);
	int xend=(int)(Math.random()*80);
	int yend=(int)(Math.random()*25);
	g.setColor(insertLine(1,255));
	g.drawLine(xstart, ystart, xend, yend);
	HttpSession session=request.getSession();
	session.setAttribute("verificationCode", sb.toString());
	ImageIO.write(bfi,"JPG",response.getOutputStream());
}
	}

	private static Color insertLine(int low, int high) {
		// TODO Auto-generated method stub
		if(low>255)
			low=255;
					if(high>255)
						high=255;
					int interval=high-low;
					int r=low+(int)(Math.random()*interval);
					int g=low+(int)(Math.random()*interval);
					int b=low+(int)(Math.random()*interval);
		return new Color(r,g,b);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */

}
