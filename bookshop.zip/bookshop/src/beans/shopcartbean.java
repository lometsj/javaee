package beans;

import java.sql.*;

public class shopcartbean {
	private String JDriver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private String drivername="jdbc:sqlserver://127.0.0.1:1433;DatabaseName=book_shop3;useUnicode=true;characterEncoding=UTF-8";
	private Connection con;
	public  Connection setConnection(){
		

		try{
			Class.forName(JDriver);
			String user="sa";
			String password="sms";
					 con=DriverManager.getConnection(drivername, user, password);
					 return con;
		}catch(Exception e){
			e.printStackTrace();
		return null;
		}
	
}
	public void endConnection(){
		try{	con.close();}
		catch(SQLException e){
			e.printStackTrace();
		}
		}
	public ResultSet query(String s){
		try{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(s);
			return rs;
		}	catch(SQLException e){
			e.printStackTrace();
			return null;
		}
	}
	public int insert(String s){
		try{
			Statement st=con.createStatement();
			int rows= st.executeUpdate(s);
			return rows;
		}catch(SQLException e){
			e.printStackTrace();
			return -1;
		}
	}
	public int delete(String s,String s2){
		try{
			String s1="delete from Car where Userid=? and isbn=?";
			PreparedStatement st1=con.prepareStatement(s1);
			
			st1.setString(1, s);
			st1.setString(2, s2);
			int r1=st1.executeUpdate();
		
			return r1;
		}catch(SQLException e){e.printStackTrace();
		return -1;}
	}
}
